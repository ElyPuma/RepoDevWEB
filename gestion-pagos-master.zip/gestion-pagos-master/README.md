# Sistema de Gestión de Pagos en PHP y MySQL
<img src="https://i0.wp.com/www.configuroweb.com/wp-content/uploads/2022/05/Sistema-de-Gestion-de-Pagos-en-PHP-y-MySQL.png?resize=800%2C500&ssl=1">

Este Sistema de Gestión de Pagos en PHP y MySQL con Código Fuente le permite al usuario administrativo las siguientes opciones:

- Agregar, Listar, Editar y Eliminar Estudiantes
- Agregar, Listar, Editar y Eliminar Pagos
- Agregar, Listar, Editar y Eliminar Materias y Niveles
- Listar el Reporte de Pagos y Usuarios

Más información en el siguiente enlace:
<a href="https://www.configuroweb.com/sistema-de-gestion-de-pagos-en-php-y-mysql/">Sistema de Gestión de Pagos en PHP y MySQL</a>
