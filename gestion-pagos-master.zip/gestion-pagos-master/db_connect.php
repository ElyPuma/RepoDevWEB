<?php
$conn = new mysqli('localhost', 'root', '', 'gestion-pagos') or die("Could not connect to mysql" . mysqli_error($con));
